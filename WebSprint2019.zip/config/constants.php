<?php

    $DB_HOST = 'innodb.endora.cz:3306';
    $DB_USER = 'public';
    $DB_PASS = 'PublicDB1';
    $DB_NAME = 'questionaire';

?>
