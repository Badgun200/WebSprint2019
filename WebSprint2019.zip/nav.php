<nav class="navbar sticky-top navbar-light bg-blue">
  <a class="navbar-brand" href="index.php">Questionaire</a>
</nav>
